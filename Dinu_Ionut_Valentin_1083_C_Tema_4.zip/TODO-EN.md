#Subject 3 (2.5 pts)
#TOPIC: REACT

# Having the following application developed using React complete the project so that :

- The application renders without crashing; (0.5 pts)
- A RobotForm component is rendered; (0.5 pts)
- The RobotForm has an `onAdd` property which is a function; (0.5 pts)
- Given that the inputs for the robot properties have the ids `name`, `type` and `mass` and that the add button has the value `add` a robot can be successfully added;(0.5 pts)
- The robot added to the list has the correct values for its attributes. (0.5 pts)